package com.iraqi.studentassistant

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
