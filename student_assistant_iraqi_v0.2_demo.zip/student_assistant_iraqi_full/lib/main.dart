import 'package:flutter/material.dart';

void main() => runApp(const IraqiStudentAssistant());

const bg = Color(0xFF080B16);
const card = Color(0xFF11172A);
const card2 = Color(0xFF151D34);
const blue = Color(0xFF4E8CFF);
const purple = Color(0xFF8B5CF6);
const cyan = Color(0xFF32D6FF);
const gold = Color(0xFFFFC857);

class IraqiStudentAssistant extends StatelessWidget {
  const IraqiStudentAssistant({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'مساعد الطالب العراقي',
        theme: ThemeData(
          brightness: Brightness.dark,
          scaffoldBackgroundColor: bg,
          colorScheme: ColorScheme.fromSeed(seedColor: blue, brightness: Brightness.dark),
          fontFamily: 'sans',
          useMaterial3: true,
        ),
        home: const StagePicker(),
      );
}

class AppLogo extends StatelessWidget {
  final double size;
  const AppLogo({super.key, this.size = 72});
  @override
  Widget build(BuildContext context) => Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(size * .27),
          gradient: const LinearGradient(colors: [Color(0xFF17254A), Color(0xFF0C1224)]),
          border: Border.all(color: blue.withOpacity(.45)),
          boxShadow: [BoxShadow(color: blue.withOpacity(.22), blurRadius: 25)],
        ),
        child: Stack(alignment: Alignment.center, children: [
          Icon(Icons.menu_book_rounded, size: size * .54, color: const Color(0xFFFFE4A6)),
          Positioned(top: size * .12, child: Icon(Icons.school_rounded, size: size * .35, color: blue)),
        ]),
      );
}

class StagePicker extends StatefulWidget {
  const StagePicker({super.key});
  @override State<StagePicker> createState() => _StagePickerState();
}
class _StagePickerState extends State<StagePicker> {
  bool loading = true;
  @override void initState() { super.initState(); Future.delayed(const Duration(milliseconds: 900), () { if (mounted) setState(() => loading = false); }); }
  @override Widget build(BuildContext context) => Scaffold(
    body: SafeArea(child: AnimatedSwitcher(duration: const Duration(milliseconds: 350), child: loading ? _splash() : _picker(context))),
  );
  Widget _splash() => Container(key: const ValueKey('splash'), alignment: Alignment.center, child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
    const AppLogo(size: 105), const SizedBox(height: 24),
    const Text('مساعد الطالب العراقي', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w800)),
    const SizedBox(height: 9), Text('دَرْسُك أسهل .. ومستقبلك أقرب', style: TextStyle(color: Colors.white54)),
    const SizedBox(height: 42), const SizedBox(width: 25, height: 25, child: CircularProgressIndicator(strokeWidth: 2)),
  ]));
  Widget _picker(BuildContext context) => Directionality(textDirection: TextDirection.rtl, child: SingleChildScrollView(padding: const EdgeInsets.fromLTRB(20, 28, 20, 30), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Row(children: [const AppLogo(size: 58), const SizedBox(width: 14), Column(crossAxisAlignment: CrossAxisAlignment.start, children: const [Text('أهلاً بك 👋', style: TextStyle(color: Colors.white60)), Text('مساعد الطالب العراقي', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w800))])]),
    const SizedBox(height: 30),
    const Text('اختار مرحلتك الدراسية', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
    const SizedBox(height: 8), const Text('حتى نرتب لك الصفوف والمواد والمساعد الذكي بشكل مناسب.', style: TextStyle(color: Colors.white54, height: 1.5)),
    const SizedBox(height: 22),
    for (final s in stages) Padding(padding: const EdgeInsets.only(bottom: 12), child: StageCard(stage: s, onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => GradePicker(stage: s))))),
    const SizedBox(height: 8),
    Center(child: TextButton.icon(onPressed: () => Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const HomeShell())), icon: const Icon(Icons.person_outline), label: const Text('الدخول كزائر'))),
  ]));
}

const stages = [
  StageData('الابتدائية', 'من الصف الأول إلى السادس', Icons.child_friendly_rounded, '6 صفوف'),
  StageData('المتوسطة', 'الأول والثاني والثالث متوسط', Icons.auto_stories_rounded, '3 صفوف'),
  StageData('الإعدادية', 'الرابع والخامس والسادس الإعدادي', Icons.school_rounded, '3 صفوف'),
  StageData('الجامعة', 'المراحل الجامعية والتخصصات', Icons.account_balance_rounded, '1–4 + دراسات عليا'),
];

class StageData { final String title, subtitle, count; final IconData icon; const StageData(this.title,this.subtitle,this.icon,this.count); }
class StageCard extends StatelessWidget { final StageData stage; final VoidCallback onTap; const StageCard({super.key,required this.stage,required this.onTap});
  @override Widget build(BuildContext context) => InkWell(onTap:onTap,borderRadius:BorderRadius.circular(22),child: Container(padding:const EdgeInsets.all(18),decoration:BoxDecoration(color:card,borderRadius:BorderRadius.circular(22),border:Border.all(color:Colors.white.withOpacity(.07)),gradient:LinearGradient(colors:[card,card2])) ,child:Row(children:[Container(width:52,height:52,decoration:BoxDecoration(color:blue.withOpacity(.12),borderRadius:BorderRadius.circular(16)),child:Icon(stage.icon,color:blue,size:27)),const SizedBox(width:14),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(stage.title,style:const TextStyle(fontSize:18,fontWeight:FontWeight.w800)),const SizedBox(height:5),Text(stage.subtitle,style:const TextStyle(color:Colors.white54,fontSize:12))])),Column(crossAxisAlignment:CrossAxisAlignment.end,children:[Text(stage.count,style:const TextStyle(color:cyan,fontSize:11,fontWeight:FontWeight.w700)),const SizedBox(height:7),const Icon(Icons.arrow_back_ios_new_rounded,size:15,color:Colors.white38)])])));
}

class GradePicker extends StatelessWidget { final StageData stage; const GradePicker({super.key,required this.stage});
  List<String> get grades { if(stage.title=='الابتدائية') return ['الصف الأول','الصف الثاني','الصف الثالث','الصف الرابع','الصف الخامس','الصف السادس']; if(stage.title=='المتوسطة') return ['الأول متوسط','الثاني متوسط','الثالث متوسط']; if(stage.title=='الإعدادية') return ['الرابع الإعدادي','الخامس الإعدادي','السادس الإعدادي']; return ['المرحلة الأولى','المرحلة الثانية','المرحلة الثالثة','المرحلة الرابعة','دراسات عليا']; }
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:Text(stage.title),backgroundColor:bg),body:Directionality(textDirection:TextDirection.rtl,child:ListView(padding:const EdgeInsets.all(20),children:[Text('اختار ${stage.title == 'الجامعة' ? 'مرحلتك' : 'صفك'}',style:const TextStyle(fontSize:28,fontWeight:FontWeight.w900)),const SizedBox(height:8),Text(stage.subtitle,style:const TextStyle(color:Colors.white54)),const SizedBox(height:22),...grades.map((g)=>Padding(padding:const EdgeInsets.only(bottom:12),child:InkWell(onTap:()=>Navigator.pushAndRemoveUntil(context,MaterialPageRoute(builder:(_)=>HomeShell(stage:stage.title,grade:g)),(r)=>false),borderRadius:BorderRadius.circular(18),child:Container(padding:const EdgeInsets.all(18),decoration:BoxDecoration(color:card,borderRadius:BorderRadius.circular(18),border:Border.all(color:Colors.white.withOpacity(.07))),child:Row(children:[CircleAvatar(backgroundColor:purple.withOpacity(.14),child:const Icon(Icons.school_rounded,color:purple)),const SizedBox(width:14),Expanded(child:Text(g,style:const TextStyle(fontWeight:FontWeight.w700,fontSize:16))),const Icon(Icons.arrow_back_ios_new_rounded,size:15,color:Colors.white38)])))))])));
}

class HomeShell extends StatefulWidget { final String stage, grade; const HomeShell({super.key,this.stage='الإعدادية',this.grade='السادس الإعدادي'}); @override State<HomeShell> createState()=>_HomeShellState(); }
class _HomeShellState extends State<HomeShell>{ int index=0; late final List<Widget> pages; @override void initState(){super.initState();pages=[Dashboard(stage:widget.stage,grade:widget.grade),const SubjectsPage(),const AiPage(),const PlannerPage(),const ProfilePage()];}
  @override Widget build(BuildContext context)=>Directionality(textDirection:TextDirection.rtl,child:Scaffold(body:pages[index],bottomNavigationBar:NavigationBar(selectedIndex:index,onDestinationSelected:(v)=>setState(()=>index=v),backgroundColor:const Color(0xFF0C1120),indicatorColor:blue.withOpacity(.16),destinations:const [NavigationDestination(icon:Icon(Icons.home_outlined),selectedIcon:Icon(Icons.home),label:'الرئيسية'),NavigationDestination(icon:Icon(Icons.menu_book_outlined),selectedIcon:Icon(Icons.menu_book),label:'موادي'),NavigationDestination(icon:Icon(Icons.auto_awesome_outlined),selectedIcon:Icon(Icons.auto_awesome),label:'الذكاء'),NavigationDestination(icon:Icon(Icons.calendar_month_outlined),selectedIcon:Icon(Icons.calendar_month),label:'المخطط'),NavigationDestination(icon:Icon(Icons.person_outline),selectedIcon:Icon(Icons.person),label:'حسابي')])));
}

class PageWrap extends StatelessWidget{final Widget child;const PageWrap({super.key,required this.child});@override Widget build(BuildContext context)=>SafeArea(child:SingleChildScrollView(padding:const EdgeInsets.fromLTRB(18,18,18,28),child:child));}
class Dashboard extends StatelessWidget{final String stage,grade;const Dashboard({super.key,required this.stage,required this.grade});
 @override Widget build(BuildContext context)=>PageWrap(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('مساء الخير 👋',style:TextStyle(color:Colors.white54)),const SizedBox(height:4),const Text('جاهز للدراسة؟',style:TextStyle(fontSize:26,fontWeight:FontWeight.w900)),const SizedBox(height:4),Text('$stage • $grade',style:const TextStyle(color:cyan,fontSize:12,fontWeight:FontWeight.w600))]),const CircleAvatar(radius:25,backgroundColor:card2,child:Icon(Icons.person,color:blue))]),const SizedBox(height:22),Container(padding:const EdgeInsets.all(20),decoration:BoxDecoration(borderRadius:BorderRadius.circular(25),gradient:const LinearGradient(colors:[Color(0xFF1D3471),Color(0xFF26174E)],begin:Alignment.topRight,end:Alignment.bottomLeft),boxShadow:[BoxShadow(color:blue.withOpacity(.12),blurRadius:28)]),child:Row(children:[Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('خطة اليوم',style:TextStyle(fontSize:19,fontWeight:FontWeight.w800)),const SizedBox(height:7),const Text('أنجز 3 مهام واحصل على 120 XP',style:TextStyle(color:Colors.white70)),const SizedBox(height:16),ClipRRect(borderRadius:BorderRadius.circular(8),child:LinearProgressIndicator(value:.72,minHeight:7,backgroundColor:Colors.white12,valueColor:const AlwaysStoppedAnimation(cyan))),const SizedBox(height:8),const Text('72% من هدفك اليومي',style:TextStyle(color:Colors.white54,fontSize:11))]),const SizedBox(width:14),const Icon(Icons.rocket_launch_rounded,size:55,color:gold)])),const SizedBox(height:20),Row(children:[StatCard('سلسلة', '7 أيام', Icons.local_fire_department_rounded, gold),const SizedBox(width:10),StatCard('XP', '1,840', Icons.bolt_rounded, cyan),const SizedBox(width:10),StatCard('المعدل', '86%', Icons.insights_rounded, purple)]),const SizedBox(height:25),SectionTitle('الوصول السريع'),const SizedBox(height:12),GridView.count(crossAxisCount:2,shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),crossAxisSpacing:10,mainAxisSpacing:10,childAspectRatio:1.65,children:[Quick('صوّر درساً',Icons.camera_alt_rounded,blue),Quick('اختبار سريع',Icons.quiz_rounded,purple),Quick('ملخص ذكي',Icons.summarize_rounded,cyan),Quick('موعد امتحان',Icons.event_available_rounded,gold)]),const SizedBox(height:25),SectionTitle('أداء هذا الأسبوع',action:'التفاصيل'),const SizedBox(height:12),Container(height:155,padding:const EdgeInsets.all(18),decoration:BoxDecoration(color:card,borderRadius:BorderRadius.circular(22),border:Border.all(color:Colors.white.withOpacity(.06))),child:Column(children:[Expanded(child:Row(crossAxisAlignment:CrossAxisAlignment.end,mainAxisAlignment:MainAxisAlignment.spaceAround,children:[for(final x in [42,66,52,82,71,90,76]) Bar(x.toDouble())])),const SizedBox(height:8),Row(mainAxisAlignment:MainAxisAlignment.spaceAround,children:['س','ح','ن','ث','ر','خ','ج'].map((e)=>Text(e,style:const TextStyle(color:Colors.white38,fontSize:10))).toList())]))]));}
}
class StatCard extends StatelessWidget{final String a,b;final IconData icon;final Color color;const StatCard(this.a,this.b,this.icon,this.color,{super.key});@override Widget build(BuildContext c)=>Expanded(child:Container(padding:const EdgeInsets.all(13),decoration:BoxDecoration(color:card,borderRadius:BorderRadius.circular(18),border:Border.all(color:Colors.white.withOpacity(.05))),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Icon(icon,color:color,size:20),const Spacer(),Text(b,style:const TextStyle(fontWeight:FontWeight.w900,fontSize:17)),Text(a,style:const TextStyle(color:Colors.white38,fontSize:10))])));}
class Bar extends StatelessWidget{final double h;const Bar(this.h,{super.key});@override Widget build(BuildContext c)=>Container(width:18,height:h,decoration:BoxDecoration(borderRadius:BorderRadius.circular(8),gradient:const LinearGradient(begin:Alignment.bottomCenter,end:Alignment.topCenter,colors:[blue,purple])));}
class Quick extends StatelessWidget{final String text;final IconData icon;final Color color;const Quick(this.text,this.icon,this.color,{super.key});@override Widget build(BuildContext c)=>Container(padding:const EdgeInsets.all(14),decoration:BoxDecoration(color:card,borderRadius:BorderRadius.circular(18),border:Border.all(color:Colors.white.withOpacity(.05))),child:Row(children:[Container(width:38,height:38,decoration:BoxDecoration(color:color.withOpacity(.12),borderRadius:BorderRadius.circular(12)),child:Icon(icon,color:color,size:20)),const SizedBox(width:9),Flexible(child:Text(text,style:const TextStyle(fontWeight:FontWeight.w700,fontSize:12)))]));}
class SectionTitle extends StatelessWidget{final String title,action;const SectionTitle(this.title,{this.action='',super.key});@override Widget build(BuildContext c)=>Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[Text(title,style:const TextStyle(fontSize:18,fontWeight:FontWeight.w800)),if(action.isNotEmpty)Text(action,style:const TextStyle(color:blue,fontSize:12))]);}

class SubjectsPage extends StatelessWidget{const SubjectsPage({super.key});final subjects=const [('الرياضيات',blue,Icons.calculate_rounded,'92%'),('الفيزياء',purple,Icons.science_rounded,'81%'),('الكيمياء',cyan,Icons.biotech_rounded,'76%'),('اللغة العربية',gold,Icons.menu_book_rounded,'88%'),('الإنكليزي',blue,Icons.translate_rounded,'84%'),('الأحياء',const Color(0xFF4ADE80),Icons.eco_rounded,'79%')];@override Widget build(BuildContext c)=>PageWrap(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('موادي',style:TextStyle(fontSize:28,fontWeight:FontWeight.w900)),const SizedBox(height:6),const Text('تابع تقدمك وحوّل أي درس إلى تدريب ذكي.',style:TextStyle(color:Colors.white54)),const SizedBox(height:20),...subjects.map((s)=>Padding(padding:const EdgeInsets.only(bottom:10),child:Container(padding:const EdgeInsets.all(16),decoration:BoxDecoration(color:card,borderRadius:BorderRadius.circular(20)),child:Row(children:[CircleAvatar(backgroundColor:s.$2.withOpacity(.13),child:Icon(s.$3,color:s.$2,size:21)),const SizedBox(width:13),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(s.$1,style:const TextStyle(fontWeight:FontWeight.w800)),const SizedBox(height:8),LinearProgressIndicator(value:double.parse(s.$4.replaceAll('%',''))/100,minHeight:5,borderRadius:BorderRadius.circular(4),backgroundColor:Colors.white10,valueColor:AlwaysStoppedAnimation(s.$2))])),const SizedBox(width:12),Text(s.$4,style:TextStyle(color:s.$2,fontWeight:FontWeight.w800))]))))]));}

class AiPage extends StatefulWidget{const AiPage({super.key});@override State<AiPage> createState()=>_AiPageState();}
class _AiPageState extends State<AiPage>{final input=TextEditingController();final msgs=<String>['مرحباً! أنا مساعدك الدراسي 🤖\nأرسل صورة درس أو اكتب موضوعاً، وسأحوّله إلى ملخص وأسئلة واختبار.'];@override Widget build(BuildContext c)=>PageWrap(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('المساعد الذكي',style:TextStyle(fontSize:28,fontWeight:FontWeight.w900)),const SizedBox(height:6),const Text('فهم الدرس • تلخيص • أسئلة • اختبار',style:TextStyle(color:Colors.white54)),const SizedBox(height:18),Container(padding:const EdgeInsets.all(18),decoration:BoxDecoration(gradient:const LinearGradient(colors:[Color(0xFF172B5D),Color(0xFF221642)]),borderRadius:BorderRadius.circular(22)),child:Row(children:[const CircleAvatar(radius:25,backgroundColor:Color(0x224E8CFF),child:Icon(Icons.auto_awesome,color:cyan)),const SizedBox(width:12),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('تحليل درس بالذكاء الاصطناعي',style:TextStyle(fontWeight:FontWeight.w800)),const SizedBox(height:5),Text('صوّر الصفحة وسنجهز لك تدريباً مناسباً.',style:TextStyle(color:Colors.white60,fontSize:11))])),IconButton(onPressed:()=>_send('📷 تم اختيار الكاميرا — في النسخة المرتبطة بالكاميرا سيبدأ OCR تلقائياً.'),icon:const Icon(Icons.camera_alt_rounded,color:cyan))])),const SizedBox(height:16),...msgs.map((m)=>Align(alignment:AlignmentDirectional.centerStart,child:Container(margin:const EdgeInsets.only(bottom:10),padding:const EdgeInsets.all(14),decoration:BoxDecoration(color:card,borderRadius:BorderRadius.circular(17)),child:Text(m,style:const TextStyle(height:1.5))))),const SizedBox(height:8),Wrap(spacing:8,runSpacing:8,children:['لخّص لي الدرس','ولّد 10 أسئلة','اختبرني','اعطني بطاقات مراجعة'].map((x)=>ActionChip(label:Text(x),onPressed:()=>_send(x))).toList()),const SizedBox(height:14),TextField(controller:input,onSubmitted:_send,textInputAction:TextInputAction.send,decoration:InputDecoration(hintText:'اكتب سؤالك هنا...',filled:true,fillColor:card,border:OutlineInputBorder(borderRadius:BorderRadius.circular(18),borderSide:BorderSide.none),suffixIcon:IconButton(onPressed:()=>_send(input.text),icon:const Icon(Icons.send_rounded,color:blue))))]));}
 void _send(String text){if(text.trim().isEmpty)return;setState((){msgs.add(text);msgs.add('تمام! في نسخة الذكاء المرتبطة بالخدمة سأحوّل طلبك إلى محتوى دراسي منظم، مع الحفاظ على مستوى $text.');input.clear();});}}

class PlannerPage extends StatelessWidget{const PlannerPage({super.key});@override Widget build(BuildContext c)=>PageWrap(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('مخططي',style:TextStyle(fontSize:28,fontWeight:FontWeight.w900)),const SizedBox(height:6),const Text('نظّم دراستك وحياتك بدون ضغط.',style:TextStyle(color:Colors.white54)),const SizedBox(height:18),Container(padding:const EdgeInsets.all(18),decoration:BoxDecoration(color:card,borderRadius:BorderRadius.circular(22)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('اليوم — الجمعة',style:TextStyle(fontWeight:FontWeight.w800)),const SizedBox(height:15),...['رياضيات — مراجعة الفصل الثالث','فيزياء — حل 20 سؤال','راحة وتركيز — 25 دقيقة','مراجعة قبل النوم'].asMap().entries.map((e)=>Padding(padding:const EdgeInsets.only(bottom:12),child:Row(children:[Icon(e.key<2?Icons.check_circle_outline:Icons.radio_button_unchecked,color:e.key<2?cyan:Colors.white30,size:21),const SizedBox(width:10),Text(e.value,style:TextStyle(decoration:e.key<2?TextDecoration.lineThrough:null,color:e.key<2?Colors.white54:Colors.white))])))])),const SizedBox(height:18),SectionTitle('التركيز'),const SizedBox(height:10),Container(padding:const EdgeInsets.all(18),decoration:BoxDecoration(gradient:const LinearGradient(colors:[Color(0xFF192B52),Color(0xFF19132D)]),borderRadius:BorderRadius.circular(22)),child:Row(children:[const Icon(Icons.timer_rounded,color:gold,size:40),const SizedBox(width:15),const Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('جلسة تركيز',style:TextStyle(fontWeight:FontWeight.w800)),Text('25 دقيقة دراسة + 5 دقائق راحة',style:TextStyle(color:Colors.white54,fontSize:11))])),FilledButton(onPressed:(){},child:const Text('ابدأ'))]))]));}

class ProfilePage extends StatelessWidget{const ProfilePage({super.key});@override Widget build(BuildContext c)=>PageWrap(child:Column(children:[const SizedBox(height:15),const CircleAvatar(radius:44,backgroundColor:card2,child:Icon(Icons.person,size:45,color:blue)),const SizedBox(height:12),const Text('الطالب',style:TextStyle(fontSize:22,fontWeight:FontWeight.w900)),const Text('طالب مجتهد • 1,840 XP',style:TextStyle(color:Colors.white54)),const SizedBox(height:24),_item(Icons.emoji_events_rounded,'الإنجازات','12 إنجاز'),_item(Icons.bar_chart_rounded,'إحصائياتي','المعدل والساعات والمواد'),_item(Icons.notifications_none_rounded,'التنبيهات','تذكير الدراسة والامتحانات'),_item(Icons.lock_outline_rounded,'الخصوصية','بياناتك أولاً'),_item(Icons.settings_outlined,'الإعدادات','المظهر واللغة والحساب'),const SizedBox(height:16),Container(padding:const EdgeInsets.all(18),decoration:BoxDecoration(color:card,borderRadius:BorderRadius.circular(20)),child:const Row(children:[Icon(Icons.workspace_premium_rounded,color:gold),SizedBox(width:12),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('مساعد الطالب PRO',style:TextStyle(fontWeight:FontWeight.w800)),SizedBox(height:4),Text('ميزات متقدمة لاحقاً: AI، OCR، مراجعة ذكية، تحليلات.',style:TextStyle(color:Colors.white54,fontSize:11))])),Text('قريباً',style:TextStyle(color:gold,fontWeight:FontWeight.w700))]))]));Widget _item(IconData i,String a,String b)=>Container(margin:const EdgeInsets.only(bottom:9),padding:const EdgeInsets.all(15),decoration:BoxDecoration(color:card,borderRadius:BorderRadius.circular(18)),child:Row(children:[Icon(i,color:blue),const SizedBox(width:12),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(a,style:const TextStyle(fontWeight:FontWeight.w700)),Text(b,style:const TextStyle(color:Colors.white38,fontSize:10))])),const Icon(Icons.arrow_back_ios_new_rounded,size:13,color:Colors.white30)]));}
